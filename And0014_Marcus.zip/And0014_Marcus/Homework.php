<?php
include_once "Header.php"
?>

<div class="container">
    <h1>Homework</h1>

<?php
include_once "footer.php"
?>
