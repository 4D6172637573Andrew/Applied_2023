<?php
ob_start();
session_start();

const  HOST = 'localhost';
const DBUSER = 'root';
const DBPASS = '';
const DBNAME = 'pay2_db';

date_default_timezone_set("Australia/Melbourne");

?>

