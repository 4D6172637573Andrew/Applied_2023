<?php
include_once "header.php";
?>

<div class="container">
    <h1>Pay project output</h1>


<?php
$rate = $_POST["rate"];
$uni_a = $_POST["uni_a"];

echo ("rate=$rate<br>");
echo ("uni_a=$uni_a<br>");
?>
</div>

<?php
include_once "footer.php";
?>
