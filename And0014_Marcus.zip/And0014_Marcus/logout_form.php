<?php
include_once "header.php";
?>

<div class="container">
    <br><h1>Logout:</h1>
</div>



<?php
include_once "footer.php";
?>
