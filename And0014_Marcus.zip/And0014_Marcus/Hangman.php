<?php
include_once "header.php"
?>


<div class="container">
    <h1>Hangman game</h1>
    <form method="post" action="Hangman_play(2).php">
        <input type="submit" value="Start the game"><br><br>
    </form>
</div

<?php
include_once "footer.php"
?>
