

$(document).on('click', ".edit_value", function (event) {
    event.preventDefault();
    alert("Editing fixed value function is not functional yet.");
});

$(document).on('click', ".calculate_pay", function (event) {
    event.preventDefault();
    alert("calculate pay function is not functional yet.");
});


